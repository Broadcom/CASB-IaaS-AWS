import boto3, json, os


def lambda_handler(event, context):
    try:
        # Read the destination bucket
        exists = os.path.isfile('s3.json')
        fileconfig = None
        if exists:
            with open('s3.json') as json_config:
                fileconfig = json.load(json_config)
                DESTINATION_BUCKET = fileconfig['DESTINATION_BUCKET']
            # Read the SNSEvent
            SNSmessage = event['Records'][0]['Sns']['Message']
            parsed_message = json.loads(SNSmessage)
            print("SNS Message: " + SNSmessage)
                
            file_name = parsed_message['aws_file_name']
            bucket_name = parsed_message['bucket_name']
            
            # List the contents of your S3 bucket
            s3 = boto3.client("s3")
            result = s3.list_objects_(Bucket=bucket_name)
            
            if "Contents" in result:
                for obj in result["Contents"]:
                    
                    if (obj["Key"] == file_name):
                    # Copy object
                        print("Copying file to Destination Bucket: " + DESTINATION_BUCKET)
                        s3.copy_object(
                            Bucket=DESTINATION_BUCKET,
                            Key=obj['Key'],
                            CopySource={'Bucket':bucket_name, 'Key':obj['Key']}
                            )
                        print("Deleting file from Source Bucket: " + bucket_name)
                        s3.delete_object(Bucket= bucket_name, Key= file_name)
            else:
                print("The bucket is empty.")    
                
        else:
            print('No config file found')
    
    except Exception as e:
        print("Error Occurred : " + str(e))
        raise

